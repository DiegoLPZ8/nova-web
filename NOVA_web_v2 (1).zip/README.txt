NOVA — sitio web inicial

1. Abre index.html en un navegador.
2. Edita script.js y agrega tu WhatsApp en NOVA_WHATSAPP.
3. En index.html cambia "PRECIO PRÓXIMAMENTE" por el precio real.
4. Cambia contacto@nova.example por tu correo o Instagram.
5. Para vender con pagos reales, conecta el botón a tu plataforma de tienda/pagos.

Los archivos de assets contienen las imágenes que proporcionaste para el primer diseño.
